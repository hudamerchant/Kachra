
<?php
    //  **LOGIN FORM ERRORS**
    define('ERROR', 'Invalid Email or Password.');
    define('PASSWORD_ERROR', 'Invalid Password.');
    
    //   **TASK/LIST ERROR**
    define('TASK_NAME_ERROR' , 'Please enter the task you want to do...');
    define('ERROR_REPEATED_TASK' , ' is already in the list');
