<?php

$user_information = [
    [
        "unique_id" => 001 ,
        "name"      => "Ali",
        "age"       => 19,
        "phone_num" => '03331234567',
    ],
    
];

$user_credentials = [
    //user_info is the child array
    [
        "unique_id"           => 001 ,
        "email"               => 'ali@example.com',
        "password"            => 'abc123',
        "user_information_id" => 001
    ],
   
];