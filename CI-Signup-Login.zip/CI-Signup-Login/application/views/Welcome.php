<div class="container">
    <div class="row">
        <div class="col-md-6 offset-md-3" >
            <a href="<?php echo site_url('/Logout') ?>">LOG OUT</a>
            <h1 class="col align-self-center" >Welcome to dashboard</h1>
        </div>
    </div>
</div>