<?php
if($_SESSION['status'] == 'logged out')
{
    header('location:'.site_url("/Login"));
}