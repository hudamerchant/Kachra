<?php
$config['error_prefix'] = '<div class="error_prefix text-danger">';
$config['error_suffix'] = '</div>';